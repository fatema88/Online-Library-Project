from django.apps import AppConfig


class PagesConfig(AppConfig):
    name = 'mysite.pages'
